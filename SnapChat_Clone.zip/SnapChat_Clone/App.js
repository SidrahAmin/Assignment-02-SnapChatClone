
      //snapchat login
import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
  checkbox,
} from "react-native";
//import { color } from "react-native/Libraries/Components/View/ReactNativeStyleAttributes";
 
export default function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
 
  
  return (

    
    <View style={styles.container}>
      <View style={{ flex: 1, 
        backgroundColor: "#fffefc",
        paddingLeft:0,
        paddingRight:17,
        borderRadius:5,
        }} >
      <Image style={{
        marginTop:20,
        marginLeft:150,
        

width: 50,
height: 50,

      }} source={require("./assets/snapchat.png")} />
    <Text style={{padding:0, 
    textAlign:"center",
    fontWeight:"800",
    fontSize:23,
    marginRight:5,
    paddingBottom:30
    }}> Log in to Snapchat</Text>
      <StatusBar style="auto" />
      <View style={styles.buttonStyleContainer}>
      
    
    
      <Text style={{marginLeft:20,
      
      }}>Username or Email</Text>
         </View>

    
      

      
      

      <View style={styles.inputView}>
      
        <TextInput
          style={styles.TextInput}
          placeholder=" "
          placeholderTextColor="#d3d7de"
          onChangeText={(email) => setEmail(email)}
        />
      </View>
 


 <View>

 <Text style={{marginLeft:20}} >Password</Text>

 </View>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder=" "
          placeholderTextColor="#d3d7de"
          secureTextEntry={true}
          onChangeText={(password) => setPassword(password)}
        />
        
      </View>

     
  
   <View>
   <Text style={{
      textAlign:"right",
      marginLeft:0,
      marginBottom:0,
      marginRight:2,
      padding:0

      }}>Forgot Password</Text>
         
   </View>
      
     <View>
     <Image style={{
        marginLeft:25,
        marginTop:10,
        

width: 320,
height: 80,

      }} source={require("./assets/capcha.jpg")} />
     </View>
      <TouchableOpacity style={styles.loginBtn}>
        <Text style={styles.loginText}>Log In</Text>
      </TouchableOpacity>

      
      

     

     

      </View>
      <view>
      <Text style={{
    
      marginLeft:10,
    
      
      }}>New To Snapchat?  </Text>
      
      <Text style={{
        
        marginTop:30,
        marginLeft:0,
      fontWeight:"bold"
    }}> Sign Up </Text>
      </view>
    </View>

    
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    padding:60,
    backgroundColor: "#ededed",
    alignItems: "center",
    justifyContent: "center",
    borderRadius:7,
    
  },
 
  image: {
    marginBottom: 40,
    width: 150,
    height: 150,
    
  },
 
  inputView: {
    backgroundColor: "#ededed",
    borderRadius: 5,
    width: 330,
    height: 45,
    marginLeft:20,
    marginBottom: 10,

    alignItems: "center",
  },
 
  TextInput: {
    borderColor:"#ededed",
    paddingRight:110,
    height: 50,
    width:330,
    flex: 1,
    padding: 10,
    marginLeft:0,
  },
 
 
 
  loginBtn: {

    width: 100,
    borderRadius: 25,
    height: 50,
    marginLeft:130,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
    backgroundColor: "#FFFC00",
    marginBottom:0
  },
  loginText:{
    color:"#1c1c1c",
    fontWeight:'bolder',
    fontSize:13
    
  },
});



